<html>
<head>
	<title>Cara Import File CSV atau Excel ke Database MySQL dengan PHP</title>
</head>
<body>
	<div style="border:1px solid #B0C4DE; padding:5px; overflow:auto; width:99%; height:98%;">
		<p><font size="3"><b>Hasil Import File CSV atau Import Excel</b></font></p>
		<p><a href="./">Kembali</a></p>
		<p>
			<table width="1100" border="0" align="center" cellpadding="0" cellspacing="0">
				<tr bgcolor="#FF6600">
					<th width="10" height="40">Nomor</td>&nbsp;
					<th width="10">ID</td>&nbsp;
					<th width="20">Tanggal</td>&nbsp;
					<th width="20">Jam</td>&nbsp; 
				</tr>
				<?php
					include "koneksi.php";
					$query=mysql_query("select * from tb_absensi");
					$no=0;	
					//menampilkan data
					while($row=mysql_fetch_array($query)){
				?>
				<tr>
					<td align="center" height="36"><?php echo $row['nomor'];?></td>
					<td align="center"><?php echo $row['id'];?></td>
					<td align="center"><?php echo $row['tgl']; ?></td>
					<td align="center"><?php echo $row['jam'];?></td>
				</tr>
				<?php
					}
				?>    
				<tr>
					<td colspan="4" height="36"> 
					<?php
					//jika data tidak ditemukan
					if(mysql_num_rows($query)==0){
						echo "<font color=red>Data tidak ditemukan!</font>";
					}
					?>
					</td>
				</tr> 
			</table>
		</p>
	</div>
</body>
</html>